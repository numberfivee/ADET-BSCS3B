import 'package:flutter/material.dart';

void main() {
  print("Hello World");
  runApp(
    MaterialApp(
      home: Text("Hello World")
  )
  );
}